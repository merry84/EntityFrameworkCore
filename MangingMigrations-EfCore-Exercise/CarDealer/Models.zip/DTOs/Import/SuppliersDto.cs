﻿namespace CarDealer.DTOs.Import;

public class SuppliersDto
{
    
}