﻿namespace CarDealer.DTOs.Import;

public class PartCarDto
{
    
}