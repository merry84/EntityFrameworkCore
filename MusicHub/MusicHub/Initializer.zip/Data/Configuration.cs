﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=MARIYA;Database=MusicHub;Trusted_Connection=True";
    }
}
