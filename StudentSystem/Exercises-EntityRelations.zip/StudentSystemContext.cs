﻿using System;
using System;
using Microsoft.EntityFrsmrworkCore;
namespace P01_StudentSystem.Data
{

    public class StudentSystemContext : DbContext
    {

    }
}